autotune.controller('SubmitRemapController', ['$scope', 'TuningService', function($scope, TuningService) {

    $scope.manufacturer = "";
    $scope.model = "";
    $scope.year = "";
    $scope.engine_size = "";
    $scope.file = null;

}]);